<!-- Your footer HTML -->
<?php wp_footer(); ?>
</body>
</html>
